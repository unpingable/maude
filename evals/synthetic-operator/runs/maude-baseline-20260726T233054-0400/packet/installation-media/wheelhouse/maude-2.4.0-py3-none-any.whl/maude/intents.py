# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum, auto


class IntentKind(Enum):
    PLAN = auto()
    PLAN_TEMPLATE = auto()
    CLEAR_TEMPLATE = auto()
    LOCK_SPEC = auto()
    BUILD = auto()
    SHOW_SPEC = auto()
    SHOW_DIFF = auto()
    APPLY = auto()
    ROLLBACK = auto()
    WHY = auto()
    STATUS = auto()
    SESSIONS = auto()
    SWITCH_SESSION = auto()
    DELETE_SESSION = auto()
    # Runtime supervisor
    SUPERVISED_LAUNCH = auto()
    SUPERVISED_LIST = auto()
    SUPERVISED_EVENTS = auto()
    SUPERVISED_APPROVE = auto()
    SUPERVISED_DENY = auto()
    SUPERVISED_KILL = auto()
    SUPERVISED_INTERVENTIONS = auto()
    SUPERVISED_PROMOTION = auto()
    SUPERVISED_DIFF = auto()
    SUPERVISED_PROMOTE = auto()
    SUPERVISED_REJECT = auto()
    SUPERVISED_FORK = auto()
    SNAPSHOT = auto()
    CONTEXT = auto()
    CLEAR = auto()
    # Session lineage
    LINEAGE = auto()
    LINEAGE_TREE = auto()
    HISTORY = auto()
    # Short aliases for tight supervised loop
    QUICK_APPROVE = auto()
    QUICK_DENY = auto()
    QUICK_PENDING = auto()
    QUICK_LAUNCH = auto()
    # M-2 plan ingestion (plan-envelope-v0 contract)
    RUN_PLAN = auto()
    # M-4 run report (composed from existing reads)
    REPORT = auto()
    # S4c grant diagnostic (read-only grant-lease status)
    GRANT_STATUS = auto()
    HELP = auto()
    CHAT = auto()


@dataclass
class Intent:
    kind: IntentKind
    payload: str


_PATTERNS: list[tuple[re.Pattern[str], IntentKind]] = [
    # Template-specific plan commands (must come before generic ^plan\b)
    (re.compile(r"^plan\s+(architecture|arch)$", re.IGNORECASE), IntentKind.PLAN_TEMPLATE),
    (re.compile(r"^plan\s+(product design|product)$", re.IGNORECASE), IntentKind.PLAN_TEMPLATE),
    (re.compile(r"^plan\s+(requirements|reqs)$", re.IGNORECASE), IntentKind.PLAN_TEMPLATE),
    (re.compile(r"^clear template$", re.IGNORECASE), IntentKind.CLEAR_TEMPLATE),
    # Generic plan
    (re.compile(r"^plan\b", re.IGNORECASE), IntentKind.PLAN),
    (re.compile(r"^let'?s plan\b", re.IGNORECASE), IntentKind.PLAN),
    (re.compile(r"^lock spec$", re.IGNORECASE), IntentKind.LOCK_SPEC),
    (re.compile(r"^freeze spec$", re.IGNORECASE), IntentKind.LOCK_SPEC),
    (re.compile(r"^build$", re.IGNORECASE), IntentKind.BUILD),
    (re.compile(r"^implement$", re.IGNORECASE), IntentKind.BUILD),
    (re.compile(r"^do it$", re.IGNORECASE), IntentKind.BUILD),
    (re.compile(r"^show spec$", re.IGNORECASE), IntentKind.SHOW_SPEC),
    (re.compile(r"^spec$", re.IGNORECASE), IntentKind.SHOW_SPEC),
    (re.compile(r"^show diff$", re.IGNORECASE), IntentKind.SHOW_DIFF),
    (re.compile(r"^diff$", re.IGNORECASE), IntentKind.SHOW_DIFF),
    (re.compile(r"^apply$", re.IGNORECASE), IntentKind.APPLY),
    (re.compile(r"^merge$", re.IGNORECASE), IntentKind.APPLY),
    (re.compile(r"^keep$", re.IGNORECASE), IntentKind.APPLY),
    (re.compile(r"^promote$", re.IGNORECASE), IntentKind.APPLY),
    (re.compile(r"^accept$", re.IGNORECASE), IntentKind.APPLY),
    (re.compile(r"^rollback$", re.IGNORECASE), IntentKind.ROLLBACK),
    (re.compile(r"^undo$", re.IGNORECASE), IntentKind.ROLLBACK),
    (re.compile(r"^discard$", re.IGNORECASE), IntentKind.ROLLBACK),
    (re.compile(r"^reject$", re.IGNORECASE), IntentKind.ROLLBACK),
    (re.compile(r"^revert$", re.IGNORECASE), IntentKind.ROLLBACK),
    (re.compile(r"^why\b", re.IGNORECASE), IntentKind.WHY),
    (re.compile(r"^blocked$", re.IGNORECASE), IntentKind.WHY),
    (re.compile(r"^status$", re.IGNORECASE), IntentKind.STATUS),
    (re.compile(r"^state$", re.IGNORECASE), IntentKind.STATUS),
    (re.compile(r"^sessions$", re.IGNORECASE), IntentKind.SESSIONS),
    (re.compile(r"^list sessions$", re.IGNORECASE), IntentKind.SESSIONS),
    (re.compile(r"^ls$", re.IGNORECASE), IntentKind.SESSIONS),
    (re.compile(r"^switch\s+(\S+)", re.IGNORECASE), IntentKind.SWITCH_SESSION),
    (re.compile(r"^session\s+(\S+)", re.IGNORECASE), IntentKind.SWITCH_SESSION),
    (re.compile(r"^resume\s+(\S+)", re.IGNORECASE), IntentKind.SWITCH_SESSION),
    (re.compile(r"^delete session\s+(\S+)", re.IGNORECASE), IntentKind.DELETE_SESSION),
    (re.compile(r"^rm session\s+(\S+)", re.IGNORECASE), IntentKind.DELETE_SESSION),
    # Runtime supervisor commands
    (re.compile(r"^supervised launch\s*(.*)", re.IGNORECASE), IntentKind.SUPERVISED_LAUNCH),
    (re.compile(r"^supervised list$", re.IGNORECASE), IntentKind.SUPERVISED_LIST),
    (re.compile(r"^supervised events\s+(\S+)", re.IGNORECASE), IntentKind.SUPERVISED_EVENTS),
    (re.compile(r"^supervised approve\s+(\S+)\s+(\S+)", re.IGNORECASE), IntentKind.SUPERVISED_APPROVE),
    (re.compile(r"^supervised deny\s+(\S+)\s+(\S+)", re.IGNORECASE), IntentKind.SUPERVISED_DENY),
    (re.compile(r"^supervised kill\s+(\S+)", re.IGNORECASE), IntentKind.SUPERVISED_KILL),
    (re.compile(r"^supervised interventions\s+(\S+)", re.IGNORECASE), IntentKind.SUPERVISED_INTERVENTIONS),
    (re.compile(r"^supervised promotion\s+(\S+)", re.IGNORECASE), IntentKind.SUPERVISED_PROMOTION),
    (re.compile(r"^supervised diff\s+(\S+)", re.IGNORECASE), IntentKind.SUPERVISED_DIFF),
    (re.compile(r"^supervised keep\s+(\S+)", re.IGNORECASE), IntentKind.SUPERVISED_PROMOTE),
    (re.compile(r"^supervised promote\s+(\S+)", re.IGNORECASE), IntentKind.SUPERVISED_PROMOTE),
    (re.compile(r"^supervised discard\s+(\S+)", re.IGNORECASE), IntentKind.SUPERVISED_REJECT),
    (re.compile(r"^supervised reject\s+(\S+)", re.IGNORECASE), IntentKind.SUPERVISED_REJECT),
    (re.compile(r"^supervised fork\s+(\S+)\s*(.*)", re.IGNORECASE), IntentKind.SUPERVISED_FORK),
    (re.compile(r"^supervised$", re.IGNORECASE), IntentKind.SUPERVISED_LIST),
    (re.compile(r"^snapshot$", re.IGNORECASE), IntentKind.SNAPSHOT),
    (re.compile(r"^overview$", re.IGNORECASE), IntentKind.SNAPSHOT),
    (re.compile(r"^wtf$", re.IGNORECASE), IntentKind.SNAPSHOT),
    (re.compile(r"^context$", re.IGNORECASE), IntentKind.CONTEXT),
    (re.compile(r"^ctx$", re.IGNORECASE), IntentKind.CONTEXT),
    (re.compile(r"^usage$", re.IGNORECASE), IntentKind.CONTEXT),
    # M-2: run a plan-envelope file. Anchored on the .md suffix so bare
    # "run" prose still falls through to chat. Trailing tokens after the path
    # (e.g. NS-0's `--model <name>` pin) are captured and forwarded verbatim —
    # the classifier routes; the runner owns flag parsing + validation.
    (re.compile(r"^run\s+(\S+\.md)(?:\s+(\S.*?))?\s*$", re.IGNORECASE), IntentKind.RUN_PLAN),
    # M-4: `report <session_id> [plan.md]` — reviewable run report.
    (re.compile(r"^report\s+(\S+)\s*(\S+\.md)?\s*$", re.IGNORECASE), IntentKind.REPORT),
    # S4c: `grant [session_id]` — read-only grant-lease diagnostic.
    (re.compile(r"^grant\s+(\S+)\s*$", re.IGNORECASE), IntentKind.GRANT_STATUS),
    (re.compile(r"^grant$", re.IGNORECASE), IntentKind.GRANT_STATUS),
    (re.compile(r"^clear$", re.IGNORECASE), IntentKind.CLEAR),
    (re.compile(r"^reset$", re.IGNORECASE), IntentKind.CLEAR),
    (re.compile(r"^lineage tree$", re.IGNORECASE), IntentKind.LINEAGE_TREE),
    (re.compile(r"^lineage$", re.IGNORECASE), IntentKind.LINEAGE),
    (re.compile(r"^branch$", re.IGNORECASE), IntentKind.LINEAGE),
    (re.compile(r"^history$", re.IGNORECASE), IntentKind.HISTORY),
    (re.compile(r"^log$", re.IGNORECASE), IntentKind.HISTORY),
    # Tight supervised loop: short aliases
    (re.compile(r"^y$"), IntentKind.QUICK_APPROVE),
    (re.compile(r"^yes$", re.IGNORECASE), IntentKind.QUICK_APPROVE),
    (re.compile(r"^approve$", re.IGNORECASE), IntentKind.QUICK_APPROVE),
    (re.compile(r"^n$"), IntentKind.QUICK_DENY),
    (re.compile(r"^deny$", re.IGNORECASE), IntentKind.QUICK_DENY),
    (re.compile(r"^pending$", re.IGNORECASE), IntentKind.QUICK_PENDING),
    (re.compile(r"^p$"), IntentKind.QUICK_PENDING),
    (re.compile(r"^go\s+(.*)", re.IGNORECASE), IntentKind.QUICK_LAUNCH),
    (re.compile(r"^help$", re.IGNORECASE), IntentKind.HELP),
    (re.compile(r"^\?$"), IntentKind.HELP),
]


def parse_intent(text: str) -> Intent:
    stripped = text.strip()
    for pattern, kind in _PATTERNS:
        m = pattern.search(stripped)
        if m:
            # For multi-group patterns (e.g. approve <session> <tool>), join with space
            if m.lastindex and m.lastindex >= 2:
                payload = " ".join(m.group(i) for i in range(1, m.lastindex + 1) if m.group(i))
            elif m.lastindex and m.lastindex >= 1:
                payload = m.group(1) if m.group(1) else stripped
            else:
                payload = stripped
            return Intent(kind=kind, payload=payload)
    return Intent(kind=IntentKind.CHAT, payload=stripped)
